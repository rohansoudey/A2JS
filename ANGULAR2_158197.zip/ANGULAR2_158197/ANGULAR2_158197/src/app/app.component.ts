/*
NAME       : app.component.ts
AUTHOR     : ROHAN SOUDEY
DESCRIPTION: Component class that will takes HTML data from AppMobileComponent class
 */

import { Component } from '@angular/core';
import { AppMobileComponent } from './app.mobilecomponent';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html'
})
export class AppComponent  {  }
