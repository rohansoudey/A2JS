/*
NAME       : app.mobile.ts
AUTHOR     : ROHAN SOUDEY
DESCRIPTION: An interface defines Properties of Mobile
 */
"use strict";
//# sourceMappingURL=app.mobile.js.map