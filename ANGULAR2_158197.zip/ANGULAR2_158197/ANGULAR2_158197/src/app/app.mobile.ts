/*
NAME       : app.mobile.ts
AUTHOR     : ROHAN SOUDEY
DESCRIPTION: An interface defines Properties of Mobile
 */


export interface IMobile
{
	mobId:number;
	mobName:string;
	mobPrice:number;
}