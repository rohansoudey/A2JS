"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*
NAME       : app.mobilecomponent.ts
AUTHOR     : ROHAN SOUDEY
DESCRIPTION: Component Class that will Provide data to app.mobilecomponent.html and contains sorting and delete bussiness Logic
 */
var core_1 = require("@angular/core");
var service_mobile_1 = require("./service.mobile");
var AppMobileComponent = (function () {
    function AppMobileComponent(mobileService) {
        this.mobileService = mobileService;
    }
    AppMobileComponent.prototype.ngOnInit = function () {
        this.mobiles = this.mobileService.getAllMobile();
    };
    /* Delete Method for deleting mobile records */
    AppMobileComponent.prototype.deleteMobile = function (mob) {
        var index = this.mobiles.indexOf(mob);
        this.mobiles.splice(index, 1); //Using splice method to delete objects from Array
        console.log(mob.mobId + " deleted");
    };
    /* Method to sort data on the basis of Mobile ID */
    AppMobileComponent.prototype.sortMobileId = function () {
        this.mobiles.sort(function (mobile1, mobile2) {
            if (mobile1.mobId < mobile2.mobId) {
                return -1;
            }
            else if (mobile1.mobId > mobile2.mobId) {
                return 1;
            }
            else {
                return 0;
            }
        });
        console.log("Sorted By Mobile Id");
    };
    /* Method to sort data on the basis of Mobile Name*/
    AppMobileComponent.prototype.sortMobileName = function () {
        this.mobiles.sort(function (mobile1, mobile2) {
            if (mobile1.mobName < mobile2.mobName) {
                return -1;
            }
            else if (mobile1.mobName > mobile2.mobName) {
                return 1;
            }
            else {
                return 0;
            }
        });
        console.log("Sorted By Mobile Name");
    };
    /* Method to sort data on the basis of Mobile price */
    AppMobileComponent.prototype.sortMobilePrice = function () {
        this.mobiles.sort(function (mobile1, mobile2) {
            if (mobile1.mobPrice < mobile2.mobPrice) {
                return -1;
            }
            else if (mobile1.mobPrice > mobile2.mobPrice) {
                return 1;
            }
            else {
                return 0;
            }
        });
        console.log("Sorted By Mobile Price");
    };
    return AppMobileComponent;
}());
AppMobileComponent = __decorate([
    core_1.Component({
        selector: 'mobile-component',
        templateUrl: './app.mobilecomponent.html',
        providers: [service_mobile_1.MobileService] //Service class provider
    }),
    __metadata("design:paramtypes", [service_mobile_1.MobileService])
], AppMobileComponent);
exports.AppMobileComponent = AppMobileComponent;
//# sourceMappingURL=app.mobilecomponent.js.map