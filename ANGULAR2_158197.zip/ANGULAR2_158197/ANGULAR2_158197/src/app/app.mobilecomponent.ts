/*
NAME       : app.mobilecomponent.ts
AUTHOR     : ROHAN SOUDEY
DESCRIPTION: Component Class that will Provide data to app.mobilecomponent.html and contains sorting and delete bussiness Logic
 */
import { Component } from '@angular/core';
import { IMobile } from './app.mobile';
import { MobileService } from './service.mobile';

@Component({
  selector: 'mobile-component',
  templateUrl:'./app.mobilecomponent.html',
  providers:[MobileService]	//Service class provider
})
export class AppMobileComponent  { 
	
	constructor(private mobileService:MobileService){}

	mobiles:IMobile[];
	
	ngOnInit():void
	{
		this.mobiles=this.mobileService.getAllMobile();
	}
	
	/* Delete Method for deleting mobile records */
	
	deleteMobile(mob:IMobile):void
	{
		let index=this.mobiles.indexOf(mob);
		this.mobiles.splice(index,1); 	//Using splice method to delete objects from Array
		console.log(mob.mobId+" deleted");	
	}
	
	/* Method to sort data on the basis of Mobile ID */
	sortMobileId():void
	{
		this.mobiles.sort(
		
				function(mobile1, mobile2) {
					if ( mobile1.mobId < mobile2.mobId ){
						return -1;
					}else if( mobile1.mobId > mobile2.mobId  ){
						return 1;
					}else{
						return 0;	
					}
				});
				
				console.log("Sorted By Mobile Id");
		
	}
	
	/* Method to sort data on the basis of Mobile Name*/
	sortMobileName():void
	{
		this.mobiles.sort(
		
				function(mobile1, mobile2) {
					if ( mobile1.mobName < mobile2.mobName ){
						return -1;
					}else if( mobile1.mobName > mobile2.mobName  ){
						return 1;
					}else{
						return 0;	
					}
				});
				
				console.log("Sorted By Mobile Name");
		
	}
	
	/* Method to sort data on the basis of Mobile price */
	sortMobilePrice():void
	{
		this.mobiles.sort(
		
				function(mobile1, mobile2) {
					if ( mobile1.mobPrice < mobile2.mobPrice ){
						return -1;
					}else if( mobile1.mobPrice > mobile2.mobPrice  ){
						return 1;
					}else{
						return 0;	
					}
				});
				
				console.log("Sorted By Mobile Price");
	}

}
