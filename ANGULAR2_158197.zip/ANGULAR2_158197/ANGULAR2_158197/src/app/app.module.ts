import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import { AppMobileComponent }  from './app.mobilecomponent';

@NgModule({
  imports:      [ BrowserModule ],
  declarations: [ AppComponent,AppMobileComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
