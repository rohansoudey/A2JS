/* 
NAME       : service.mobile.ts
AUTHOR     : ROHAN SOUDEY
DESCRIPTION: Contains service class - Provide mobile data to our components

 */

import { Component} from '@angular/core';
import { Injectable }     from '@angular/core';
import {IMobile} from "./app.mobile";


@Injectable()

export class MobileService{

	/* Method that returns the Mobile data */
	
	 getAllMobile():IMobile[]
	{
		return[
				{"mobId":1001,
				"mobName":"iPhone",
				"mobPrice":76661.1
				},
				{
				"mobId":1002,
				"mobName":"MicroMax",
				"mobPrice":126661.1
				},
				{
				"mobId":1003,
				"mobName":"Coolpad",
				"mobPrice":7823
				},
				{
				"mobId":1004,
				"mobName":"HTC",
				"mobPrice":8876
				},
				{
				"mobId":1005,
				"mobName":"LG",
				"mobPrice":46661.1
				}
		];
	} 
}